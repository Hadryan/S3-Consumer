from __future__ import print_function
import json
import boto3
from botocore.exceptions import ClientError
import os
import io
import ast


def lambda_handler(event, context):
    s3_client = boto3.client('s3')
    s3_resource = boto3.resource('s3')
    sqs_client = boto3.client('sqs')
    sns_client = boto3.client('sns')
    print(event)
    
# Get key and bucket from message.
    print('Getting key from the message...')
    key, bucket = parse_records_from_lambda(event)
    destination_bucket = os.environ['Destination_S3_Bucket']
    sns_topic = os.environ['SNSTopic']
    copy_source = {'Bucket': bucket, 'Key': key}
# Copy source key and source bucket information to destination bucket with same key as source key.   
    print('Writing to the another bucket')
    s3_resource.meta.client.copy(copy_source, destination_bucket, key)
    #Publish a message to the SNS topic after successful copy to the destination bucket.
    message = {"Successfully copied the following file from source bucket to destination bucket": key}
    response = sns_client.publish(
    TopicArn=sns_topic,
    Message=json.dumps({'default': json.dumps(message)}),
    MessageStructure='json'
    )
    
def parse_records_from_lambda(event):
    ''' Parses the response from actual lambda notification
        from S3 passed on to the queue and extracts the key,
        or raises TypeError if it is a test message'''

    records = event['Records']
    
    if len(records) == 1:
        record = records[0]
    else:
        raise TypeError("Lambda Error: Too many records")
    message = records[0]
    body = message["body"]
    str_to_dict = ast.literal_eval(body)
    input_message = str_to_dict["Records"]
    bucket = input_message[0]["s3"]["bucket"]["name"]
    key = input_message[0]["s3"]["object"]["key"]
    print(bucket)
    print(key)
    return key, bucket
